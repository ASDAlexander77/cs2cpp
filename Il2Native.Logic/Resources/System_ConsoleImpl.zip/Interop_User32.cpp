#include "System.Console.h"

namespace System_Console { 
    namespace _ = ::System_Console;
    // Method : Interop.User32.GetKeyState(int)
    int16_t Interop_User32::GetKeyState(int32_t virtualKeyCode)
    {
        throw 3221274624U;
    }

}

namespace System_Console { 
    namespace _ = ::System_Console;
}
