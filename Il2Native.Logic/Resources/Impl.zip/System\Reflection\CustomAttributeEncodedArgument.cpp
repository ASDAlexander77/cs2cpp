#include "CoreLib.h"

// Method : System.Reflection.CustomAttributeEncodedArgument.ParseAttributeArguments(System.IntPtr, int, ref System.Reflection.CustomAttributeCtorParameter[], ref System.Reflection.CustomAttributeNamedParameter[], System.Reflection.RuntimeAssembly)
void CoreLib::System::Reflection::CustomAttributeEncodedArgument::ParseAttributeArguments_Ref_Ref(CoreLib::System::IntPtr pCa, int32_t cCa, __array<CoreLib::System::Reflection::CustomAttributeCtorParameter>*& CustomAttributeCtorParameters, __array<CoreLib::System::Reflection::CustomAttributeNamedParameter>*& CustomAttributeTypedArgument, CoreLib::System::Reflection::RuntimeAssembly* assembly)
{
    throw 3221274624U;
}
