#include "CoreLib.h"

// Method : System.Runtime.Remoting.RemotingServices.IsTransparentProxy(object)
bool CoreLib::System::Runtime::Remoting::RemotingServices::IsTransparentProxy(object* proxy)
{
    throw 3221274624U;
}
