#include "CoreLib.h"

// Method : System.Runtime.CompilerServices.JitHelpers.UnsafeSetArrayElement(object[], int, object)
void CoreLib::System::Runtime::CompilerServices::JitHelpers::UnsafeSetArrayElement(__array<object*>* target, int32_t index, object* element)
{
    throw 0xC000C000;
}
