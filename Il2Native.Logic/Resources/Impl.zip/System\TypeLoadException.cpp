#include "CoreLib.h"

// Method : System.TypeLoadException.GetTypeLoadExceptionMessage(int, System.Runtime.CompilerServices.StringHandleOnStack)
void CoreLib::System::TypeLoadException::GetTypeLoadExceptionMessage(int32_t resourceId, CoreLib::System::Runtime::CompilerServices::StringHandleOnStack retString)
{
    throw 0xC000C000;
}
