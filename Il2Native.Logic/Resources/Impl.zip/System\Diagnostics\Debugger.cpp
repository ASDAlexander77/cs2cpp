#include "CoreLib.h"

// Method : System.Diagnostics.Debugger.IsAttached.get
bool CoreLib::System::Diagnostics::Debugger::get_IsAttached()
{
    throw 3221274624U;
}

// Method : System.Diagnostics.Debugger.Break()
void CoreLib::System::Diagnostics::Debugger::Break()
{
    throw 3221274624U;
}
