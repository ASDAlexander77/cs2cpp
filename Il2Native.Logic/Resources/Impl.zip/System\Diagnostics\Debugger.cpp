#include "CoreLib.h"

// Method : System.Diagnostics.Debugger.IsAttached.get
bool CoreLib::System::Diagnostics::Debugger::get_IsAttached()
{
    throw 0xC000C000;
}

// Method : System.Diagnostics.Debugger.Break()
void CoreLib::System::Diagnostics::Debugger::Break()
{
    throw 0xC000C000;
}
