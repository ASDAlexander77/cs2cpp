#include "CoreLib.h"

// Method : System.Reflection.PseudoCustomAttribute._GetSecurityAttributes(System.Reflection.RuntimeModule, int, bool, out object[])
void CoreLib::System::Reflection::PseudoCustomAttribute::_GetSecurityAttributes_Out(CoreLib::System::Reflection::RuntimeModule* module, int32_t token, bool assembly, __array<object*>*& securityAttributes)
{
    throw 0xC000C000;
}
