#include "CoreLib.h"

// Method : System.Runtime.InteropServices.SafeBuffer.PtrToStructureNative(byte*, System.TypedReference, uint)
void CoreLib::System::Runtime::InteropServices::SafeBuffer::PtrToStructureNative(uint8_t* ptr, CoreLib::System::TypedReference structure, uint32_t sizeofT)
{
    throw 3221274624U;
}

// Method : System.Runtime.InteropServices.SafeBuffer.StructureToPtrNative(System.TypedReference, byte*, uint)
void CoreLib::System::Runtime::InteropServices::SafeBuffer::StructureToPtrNative(CoreLib::System::TypedReference structure, uint8_t* ptr, uint32_t sizeofT)
{
    throw 3221274624U;
}
