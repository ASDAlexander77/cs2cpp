#include "CoreLib.h"

// Method : System.Reflection.LoaderAllocatorScout.Destroy(System.IntPtr)
bool CoreLib::System::Reflection::LoaderAllocatorScout::Destroy(CoreLib::System::IntPtr nativeLoaderAllocator)
{
    throw 0xC000C000;
}
