#include "CoreLib.h"

// Method : System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(object)
object* CoreLib::System::Runtime::CompilerServices::RuntimeHelpers::GetObjectValue(object* obj)
{
    throw 3221274624U;
}

// Method : System.Runtime.CompilerServices.RuntimeHelpers.RunClassConstructor(System.RuntimeTypeHandle)
void CoreLib::System::Runtime::CompilerServices::RuntimeHelpers::RunClassConstructor(CoreLib::System::RuntimeTypeHandle type)
{
    throw 3221274624U;
}

// Method : System.Runtime.CompilerServices.RuntimeHelpers.OffsetToStringData.get
int32_t CoreLib::System::Runtime::CompilerServices::RuntimeHelpers::get_OffsetToStringData()
{
    return 0;
}
