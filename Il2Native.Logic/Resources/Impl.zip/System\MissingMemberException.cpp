#include "CoreLib.h"

// Method : System.MissingMemberException.FormatSignature(byte[])
string* CoreLib::System::MissingMemberException::FormatSignature(__array<uint8_t>* signature)
{
    throw 3221274624U;
}
