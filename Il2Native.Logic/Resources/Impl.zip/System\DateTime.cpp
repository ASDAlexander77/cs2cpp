#include "CoreLib.h"

// Method : System.DateTime.GetSystemTimeAsFileTime()
int64_t CoreLib::System::DateTime::GetSystemTimeAsFileTime()
{
    throw 3221274624U;
}
