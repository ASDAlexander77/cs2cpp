#include "CoreLib.h"

// Method : System.Reflection.SecurityContextFrame.Push(System.Reflection.RuntimeAssembly)
void CoreLib::System::Reflection::SecurityContextFrame::Push(CoreLib::System::Reflection::RuntimeAssembly* assembly)
{
    throw 3221274624U;
}

// Method : System.Reflection.SecurityContextFrame.Pop()
void CoreLib::System::Reflection::SecurityContextFrame::Pop()
{
    throw 3221274624U;
}
