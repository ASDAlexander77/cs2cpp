#include "CoreLib.h"

// Method : System.TypedReference.InternalToObject(void*)
object* CoreLib::System::TypedReference::InternalToObject(void* value)
{
    throw 3221274624U;
}
