#include "CoreLib.h"

// Method : System.TypedReference.InternalToObject(void*)
object* CoreLib::System::TypedReference::InternalToObject(void* value)
{
    throw 0xC000C000;
}
