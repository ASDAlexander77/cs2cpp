#include "CoreLib.h"

// Method : System.Utf8String.EqualsCaseSensitive(void*, void*, int)
bool CoreLib::System::Utf8String::EqualsCaseSensitive(void* szLhs, void* szRhs, int32_t cSz)
{
    throw 3221274624U;
}

// Method : System.Utf8String.EqualsCaseInsensitive(void*, void*, int)
bool CoreLib::System::Utf8String::EqualsCaseInsensitive(void* szLhs, void* szRhs, int32_t cSz)
{
    throw 3221274624U;
}

// Method : System.Utf8String.HashCaseInsensitive(void*, int)
uint32_t CoreLib::System::Utf8String::HashCaseInsensitive(void* sz, int32_t cSz)
{
    throw 3221274624U;
}
