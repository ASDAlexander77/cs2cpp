#include "CoreLib.h"

// Method : System.Reflection.RuntimeModule.GetType(System.Reflection.RuntimeModule, string, bool, bool, System.Runtime.CompilerServices.ObjectHandleOnStack)
void CoreLib::System::Reflection::RuntimeModule::GetType(CoreLib::System::Reflection::RuntimeModule* module, string* className, bool ignoreCase, bool throwOnError, CoreLib::System::Runtime::CompilerServices::ObjectHandleOnStack type)
{
    throw 3221274624U;
}

// Method : System.Reflection.RuntimeModule.nIsTransientInternal(System.Reflection.RuntimeModule)
bool CoreLib::System::Reflection::RuntimeModule::nIsTransientInternal(CoreLib::System::Reflection::RuntimeModule* module)
{
    throw 3221274624U;
}

// Method : System.Reflection.RuntimeModule.GetScopeName(System.Reflection.RuntimeModule, System.Runtime.CompilerServices.StringHandleOnStack)
void CoreLib::System::Reflection::RuntimeModule::GetScopeName(CoreLib::System::Reflection::RuntimeModule* module, CoreLib::System::Runtime::CompilerServices::StringHandleOnStack retString)
{
    throw 3221274624U;
}

// Method : System.Reflection.RuntimeModule.GetFullyQualifiedName(System.Reflection.RuntimeModule, System.Runtime.CompilerServices.StringHandleOnStack)
void CoreLib::System::Reflection::RuntimeModule::GetFullyQualifiedName(CoreLib::System::Reflection::RuntimeModule* module, CoreLib::System::Runtime::CompilerServices::StringHandleOnStack retString)
{
    throw 3221274624U;
}

// Method : System.Reflection.RuntimeModule.GetTypes(System.Reflection.RuntimeModule)
__array<CoreLib::System::RuntimeType*>* CoreLib::System::Reflection::RuntimeModule::GetTypes(CoreLib::System::Reflection::RuntimeModule* module)
{
    throw 3221274624U;
}

// Method : System.Reflection.RuntimeModule.IsResource(System.Reflection.RuntimeModule)
bool CoreLib::System::Reflection::RuntimeModule::IsResource(CoreLib::System::Reflection::RuntimeModule* module)
{
    throw 3221274624U;
}
