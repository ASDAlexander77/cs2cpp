#include "CoreLib.h"

// Method : System.IO.__DebugOutputTextWriter.wprintf(char*, __arglist)
int32_t CoreLib::System::IO::__DebugOutputTextWriter::wprintf(wchar_t* format, ...)
{
    throw 3221274624U;
}
