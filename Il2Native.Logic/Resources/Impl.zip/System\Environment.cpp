#include "CoreLib.h"

// Method : System.Environment.GetProcessorCount()
int32_t CoreLib::System::Environment::GetProcessorCount()
{
    throw 3221274624U;
}

// Method : System.Environment.TickCount.get
int32_t CoreLib::System::Environment::get_TickCount()
{
    throw 3221274624U;
}

// Method : System.Environment._Exit(int)
void CoreLib::System::Environment::_Exit(int32_t exitCode)
{
    throw 3221274624U;
}
