#include "CoreLib.h"

// Method : System.RuntimeType.GetGUID(ref System.Guid)
void CoreLib::System::RuntimeType::GetGUID_Ref(CoreLib::System::Guid& result)
{
    throw 3221274624U;
}

// Method : System.RuntimeType.CanValueSpecialCast(System.RuntimeType, System.RuntimeType)
bool CoreLib::System::RuntimeType::CanValueSpecialCast(CoreLib::System::RuntimeType* valueType, CoreLib::System::RuntimeType* targetType)
{
    throw 3221274624U;
}

// Method : System.RuntimeType.AllocateValueType(System.RuntimeType, object, bool)
object* CoreLib::System::RuntimeType::AllocateValueType(CoreLib::System::RuntimeType* type, object* value, bool fForceTypeChange)
{
    throw 3221274624U;
}

// Method : System.RuntimeType._CreateEnum(System.RuntimeType, long)
object* CoreLib::System::RuntimeType::_CreateEnum(CoreLib::System::RuntimeType* enumType, int64_t value)
{
    throw 3221274624U;
}
