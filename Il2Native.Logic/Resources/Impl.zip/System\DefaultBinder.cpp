#include "CoreLib.h"

// Method : System.DefaultBinder.CanConvertPrimitive(System.RuntimeType, System.RuntimeType)
bool CoreLib::System::DefaultBinder::CanConvertPrimitive(CoreLib::System::RuntimeType* source, CoreLib::System::RuntimeType* target)
{
    throw 3221274624U;
}

// Method : System.DefaultBinder.CanConvertPrimitiveObjectToType(object, System.RuntimeType)
bool CoreLib::System::DefaultBinder::CanConvertPrimitiveObjectToType(object* source, CoreLib::System::RuntimeType* type)
{
    throw 3221274624U;
}
