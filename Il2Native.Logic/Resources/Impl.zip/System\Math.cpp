#include "CoreLib.h"

// Method : System.Math.Acos(double)
double CoreLib::System::Math::Acos(double d)
{
    throw 3221274624U;
}

// Method : System.Math.Asin(double)
double CoreLib::System::Math::Asin(double d)
{
    throw 3221274624U;
}

// Method : System.Math.Atan(double)
double CoreLib::System::Math::Atan(double d)
{
    throw 3221274624U;
}

// Method : System.Math.Atan2(double, double)
double CoreLib::System::Math::Atan2(double y, double x)
{
    throw 3221274624U;
}

// Method : System.Math.Ceiling(double)
double CoreLib::System::Math::Ceiling(double a)
{
    throw 3221274624U;
}

// Method : System.Math.Cos(double)
double CoreLib::System::Math::Cos(double d)
{
    throw 3221274624U;
}

// Method : System.Math.Cosh(double)
double CoreLib::System::Math::Cosh(double value)
{
    throw 3221274624U;
}

// Method : System.Math.Floor(double)
double CoreLib::System::Math::Floor(double d)
{
    throw 3221274624U;
}

// Method : System.Math.Sin(double)
double CoreLib::System::Math::Sin(double a)
{
    throw 3221274624U;
}

// Method : System.Math.Tan(double)
double CoreLib::System::Math::Tan(double a)
{
    throw 3221274624U;
}

// Method : System.Math.Sinh(double)
double CoreLib::System::Math::Sinh(double value)
{
    throw 3221274624U;
}

// Method : System.Math.Tanh(double)
double CoreLib::System::Math::Tanh(double value)
{
    throw 3221274624U;
}

// Method : System.Math.Round(double)
double CoreLib::System::Math::Round(double a)
{
    throw 3221274624U;
}

// Method : System.Math.SplitFractionDouble(double*)
double CoreLib::System::Math::SplitFractionDouble(double* value)
{
    throw 3221274624U;
}

// Method : System.Math.Sqrt(double)
double CoreLib::System::Math::Sqrt(double d)
{
    throw 3221274624U;
}

// Method : System.Math.Log(double)
double CoreLib::System::Math::Log(double d)
{
    throw 3221274624U;
}

// Method : System.Math.Log10(double)
double CoreLib::System::Math::Log10(double d)
{
    throw 3221274624U;
}

// Method : System.Math.Exp(double)
double CoreLib::System::Math::Exp(double d)
{
    throw 3221274624U;
}

// Method : System.Math.Pow(double, double)
double CoreLib::System::Math::Pow(double x, double y)
{
    throw 3221274624U;
}

// Method : System.Math.Abs(float)
float CoreLib::System::Math::Abs(float value)
{
    throw 3221274624U;
}

// Method : System.Math.Abs(double)
double CoreLib::System::Math::Abs(double value)
{
    throw 3221274624U;
}
