#include "CoreLib.h"

// Method : System.Signature.GetSignature(void*, int, System.RuntimeFieldHandleInternal, System.IRuntimeMethodInfo, System.RuntimeType)
void CoreLib::System::Signature::GetSignature(void* pCorSig, int32_t cCorSig, CoreLib::System::RuntimeFieldHandleInternal fieldHandle, CoreLib::System::IRuntimeMethodInfo* methodHandle, CoreLib::System::RuntimeType* declaringType)
{
    throw 0xC000C000;
}

// Method : System.Signature.CompareSig(System.Signature, System.Signature)
bool CoreLib::System::Signature::CompareSig(CoreLib::System::Signature* sig1, CoreLib::System::Signature* sig2)
{
    throw 0xC000C000;
}

// Method : System.Signature.GetCustomModifiers(int, bool)
__array<CoreLib::System::Type*>* CoreLib::System::Signature::GetCustomModifiers(int32_t position, bool required)
{
    throw 0xC000C000;
}
