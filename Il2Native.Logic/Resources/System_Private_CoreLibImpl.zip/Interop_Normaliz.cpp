#include "System.Private.CoreLib.h"

namespace CoreLib { 
    namespace _ = ::CoreLib;
    // Method : Interop.Normaliz.IdnToAscii(uint, System.IntPtr, int, System.IntPtr, int)
    int32_t Interop_Normaliz::IdnToAscii(uint32_t dwFlags, ::CoreLib::System::IntPtr lpUnicodeCharStr, int32_t cchUnicodeChar, ::CoreLib::System::IntPtr lpASCIICharStr, int32_t cchASCIIChar)
    {
        throw 3221274624U;
    }
    
    // Method : Interop.Normaliz.IdnToUnicode(uint, System.IntPtr, int, System.IntPtr, int)
    int32_t Interop_Normaliz::IdnToUnicode(uint32_t dwFlags, ::CoreLib::System::IntPtr lpASCIICharStr, int32_t cchASCIIChar, ::CoreLib::System::IntPtr lpUnicodeCharStr, int32_t cchUnicodeChar)
    {
        throw 3221274624U;
    }
    
    // Method : Interop.Normaliz.IsNormalizedString(int, string, int)
    bool Interop_Normaliz::IsNormalizedString(int32_t normForm, string* source, int32_t length)
    {
        throw 3221274624U;
    }
    
    // Method : Interop.Normaliz.NormalizeString(int, string, int, char[], int)
    int32_t Interop_Normaliz::NormalizeString(int32_t normForm, string* source, int32_t sourceLength, __array<char16_t>* destination, int32_t destinationLength)
    {
        throw 3221274624U;
    }

}

namespace CoreLib { 
    namespace _ = ::CoreLib;
}
