#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Reflection { namespace Emit { 
    namespace _ = ::CoreLib::System::Reflection::Emit;
    // Method : System.Reflection.Emit.PunkSafeHandle.nGetDReleaseTarget()
    ::CoreLib::System::IntPtr PunkSafeHandle::nGetDReleaseTarget()
    {
        throw 3221274624U;
    }

}}}}

namespace CoreLib { namespace System { namespace Reflection { namespace Emit { 
    namespace _ = ::CoreLib::System::Reflection::Emit;
}}}}
