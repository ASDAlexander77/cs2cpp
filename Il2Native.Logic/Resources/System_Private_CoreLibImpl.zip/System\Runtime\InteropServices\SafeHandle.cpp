#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Runtime { namespace InteropServices { 
    namespace _ = ::CoreLib::System::Runtime::InteropServices;
    // Method : System.Runtime.InteropServices.SafeHandle.InternalFinalize()
    void SafeHandle::InternalFinalize()
    {
        throw 3221274624U;
    }
    
    // Method : System.Runtime.InteropServices.SafeHandle.InternalDispose()
    void SafeHandle::InternalDispose()
    {
        throw 3221274624U;
    }
    
    // Method : System.Runtime.InteropServices.SafeHandle.SetHandleAsInvalid()
    void SafeHandle::SetHandleAsInvalid()
    {
        throw 3221274624U;
    }
    
    // Method : System.Runtime.InteropServices.SafeHandle.DangerousAddRef(ref bool)
    void SafeHandle::DangerousAddRef_Ref(bool& success)
    {
        throw 3221274624U;
    }
    
    // Method : System.Runtime.InteropServices.SafeHandle.DangerousRelease()
    void SafeHandle::DangerousRelease()
    {
        throw 3221274624U;
    }

}}}}

namespace CoreLib { namespace System { namespace Runtime { namespace InteropServices { 
    namespace _ = ::CoreLib::System::Runtime::InteropServices;
}}}}
