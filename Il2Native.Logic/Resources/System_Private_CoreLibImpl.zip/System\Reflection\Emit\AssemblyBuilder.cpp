#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Reflection { namespace Emit { 
    namespace _ = ::CoreLib::System::Reflection::Emit;
    // Method : System.Reflection.Emit.AssemblyBuilder.GetInMemoryAssemblyModule(System.Reflection.RuntimeAssembly)
    ::CoreLib::System::Reflection::RuntimeModule* AssemblyBuilder::GetInMemoryAssemblyModule(::CoreLib::System::Reflection::RuntimeAssembly* assembly)
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.Emit.AssemblyBuilder.nCreateDynamicAssembly(System.AppDomain, System.Reflection.AssemblyName, ref System.Threading.StackCrawlMark, System.Reflection.Emit.AssemblyBuilderAccess)
    ::CoreLib::System::Reflection::Assembly* AssemblyBuilder::nCreateDynamicAssembly_Ref(::CoreLib::System::AppDomain* domain, ::CoreLib::System::Reflection::AssemblyName* name, ::CoreLib::System::Threading::StackCrawlMark__enum& stackMark, _::AssemblyBuilderAccess__enum access)
    {
        throw 3221274624U;
    }

}}}}

namespace CoreLib { namespace System { namespace Reflection { namespace Emit { 
    namespace _ = ::CoreLib::System::Reflection::Emit;
}}}}
