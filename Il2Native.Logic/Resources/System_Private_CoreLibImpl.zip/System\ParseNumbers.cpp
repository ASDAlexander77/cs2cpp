#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.ParseNumbers.StringToLong(string, int, int, int*)
    int64_t ParseNumbers::StringToLong(string* s, int32_t radix, int32_t flags, int32_t* currPos)
    {
        throw 3221274624U;
    }
    
    // Method : System.ParseNumbers.StringToInt(string, int, int, int*)
    int32_t ParseNumbers::StringToInt(string* s, int32_t radix, int32_t flags, int32_t* currPos)
    {
        throw 3221274624U;
    }
    
    // Method : System.ParseNumbers.IntToString(int, int, int, char, int)
    string* ParseNumbers::IntToString(int32_t l, int32_t radix, int32_t width, char16_t paddingChar, int32_t flags)
    {
        throw 3221274624U;
    }
    
    // Method : System.ParseNumbers.LongToString(long, int, int, char, int)
    string* ParseNumbers::LongToString(int64_t l, int32_t radix, int32_t width, char16_t paddingChar, int32_t flags)
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
