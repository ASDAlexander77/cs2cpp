#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Runtime { namespace Serialization { 
    namespace _ = ::CoreLib::System::Runtime::Serialization;
    // Method : System.Runtime.Serialization.FormatterServices.nativeGetUninitializedObject(System.RuntimeType)
    object* FormatterServices::nativeGetUninitializedObject(::CoreLib::System::RuntimeType* type)
    {
        throw 3221274624U;
    }

}}}}

namespace CoreLib { namespace System { namespace Runtime { namespace Serialization { 
    namespace _ = ::CoreLib::System::Runtime::Serialization;
}}}}
