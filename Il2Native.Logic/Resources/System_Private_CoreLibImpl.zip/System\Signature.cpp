#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.Signature.GetSignature(void*, int, System.RuntimeFieldHandleInternal, System.IRuntimeMethodInfo, System.RuntimeType)
    void Signature::GetSignature(void* pCorSig, int32_t cCorSig, _::RuntimeFieldHandleInternal fieldHandle, _::IRuntimeMethodInfo* methodHandle, _::RuntimeType* declaringType)
    {
        throw 3221274624U;
    }
    
    // Method : System.Signature.CompareSig(System.Signature, System.Signature)
    bool Signature::CompareSig(_::Signature* sig1, _::Signature* sig2)
    {
        throw 3221274624U;
    }
    
    // Method : System.Signature.GetCustomModifiers(int, bool)
    __array<_::Type*>* Signature::GetCustomModifiers(int32_t position, bool required)
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
