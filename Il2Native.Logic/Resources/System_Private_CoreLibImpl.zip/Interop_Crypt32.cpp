#include "System.Private.CoreLib.h"

namespace CoreLib { 
    namespace _ = ::CoreLib;
    // Method : Interop.Crypt32.CryptProtectMemory(System.Security.SafeBSTRHandle, uint, uint)
    bool Interop_Crypt32::CryptProtectMemory(::CoreLib::System::Security::SafeBSTRHandle* pData, uint32_t cbData, uint32_t dwFlags)
    {
        throw 3221274624U;
    }
    
    // Method : Interop.Crypt32.CryptUnprotectMemory(System.Security.SafeBSTRHandle, uint, uint)
    bool Interop_Crypt32::CryptUnprotectMemory(::CoreLib::System::Security::SafeBSTRHandle* pData, uint32_t cbData, uint32_t dwFlags)
    {
        throw 3221274624U;
    }

}

namespace CoreLib { 
    namespace _ = ::CoreLib;
}
