#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace StubHelpers { 
    namespace _ = ::CoreLib::System::StubHelpers;
    // Method : System.StubHelpers.ValueClassMarshaler.ConvertToNative(System.IntPtr, System.IntPtr, System.IntPtr, ref System.StubHelpers.CleanupWorkList)
    void ValueClassMarshaler::ConvertToNative_Ref(::CoreLib::System::IntPtr dst, ::CoreLib::System::IntPtr src, ::CoreLib::System::IntPtr pMT, _::CleanupWorkList*& pCleanupWorkList)
    {
        throw 3221274624U;
    }
    
    // Method : System.StubHelpers.ValueClassMarshaler.ConvertToManaged(System.IntPtr, System.IntPtr, System.IntPtr)
    void ValueClassMarshaler::ConvertToManaged(::CoreLib::System::IntPtr dst, ::CoreLib::System::IntPtr src, ::CoreLib::System::IntPtr pMT)
    {
        throw 3221274624U;
    }
    
    // Method : System.StubHelpers.ValueClassMarshaler.ClearNative(System.IntPtr, System.IntPtr)
    void ValueClassMarshaler::ClearNative(::CoreLib::System::IntPtr dst, ::CoreLib::System::IntPtr pMT)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace StubHelpers { 
    namespace _ = ::CoreLib::System::StubHelpers;
}}}
