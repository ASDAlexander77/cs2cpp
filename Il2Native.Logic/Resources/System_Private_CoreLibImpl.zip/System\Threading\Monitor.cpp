#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Threading { 
    namespace _ = ::CoreLib::System::Threading;
    // Method : System.Threading.Monitor.Enter(object)
    void Monitor::Enter(object* obj)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Monitor.ReliableEnter(object, ref bool)
    void Monitor::ReliableEnter_Ref(object* obj, bool& lockTaken)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Monitor.Exit(object)
    void Monitor::Exit(object* obj)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Monitor.ReliableEnterTimeout(object, int, ref bool)
    void Monitor::ReliableEnterTimeout_Ref(object* obj, int32_t timeout, bool& lockTaken)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Monitor.IsEnteredNative(object)
    bool Monitor::IsEnteredNative(object* obj)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Monitor.ObjWait(bool, int, object)
    bool Monitor::ObjWait(bool exitContext, int32_t millisecondsTimeout, object* obj)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Monitor.ObjPulse(object)
    void Monitor::ObjPulse(object* obj)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Monitor.ObjPulseAll(object)
    void Monitor::ObjPulseAll(object* obj)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Threading { 
    namespace _ = ::CoreLib::System::Threading;
}}}
