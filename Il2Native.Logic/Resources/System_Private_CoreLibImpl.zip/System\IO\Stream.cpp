#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace IO { 
    namespace _ = ::CoreLib::System::IO;
    // Method : System.IO.Stream.HasOverriddenBeginEndRead()
    bool Stream::HasOverriddenBeginEndRead()
    {
        throw 3221274624U;
    }
    
    // Method : System.IO.Stream.HasOverriddenBeginEndWrite()
    bool Stream::HasOverriddenBeginEndWrite()
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace IO { 
    namespace _ = ::CoreLib::System::IO;
}}}
