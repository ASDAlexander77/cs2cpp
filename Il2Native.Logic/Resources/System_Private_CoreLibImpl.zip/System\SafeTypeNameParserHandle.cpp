#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.SafeTypeNameParserHandle._ReleaseTypeNameParser(System.IntPtr)
    void SafeTypeNameParserHandle::_ReleaseTypeNameParser(_::IntPtr pTypeNameParser)
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
