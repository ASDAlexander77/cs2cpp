#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.TypeNameParser._CreateTypeNameParser(string, System.Runtime.CompilerServices.ObjectHandleOnStack, bool)
    void TypeNameParser::_CreateTypeNameParser(string* typeName, _::Runtime::CompilerServices::ObjectHandleOnStack retHandle, bool throwOnError)
    {
        throw 3221274624U;
    }
    
    // Method : System.TypeNameParser._GetNames(System.SafeTypeNameParserHandle, System.Runtime.CompilerServices.ObjectHandleOnStack)
    void TypeNameParser::_GetNames(_::SafeTypeNameParserHandle* pTypeNameParser, _::Runtime::CompilerServices::ObjectHandleOnStack retArray)
    {
        throw 3221274624U;
    }
    
    // Method : System.TypeNameParser._GetTypeArguments(System.SafeTypeNameParserHandle, System.Runtime.CompilerServices.ObjectHandleOnStack)
    void TypeNameParser::_GetTypeArguments(_::SafeTypeNameParserHandle* pTypeNameParser, _::Runtime::CompilerServices::ObjectHandleOnStack retArray)
    {
        throw 3221274624U;
    }
    
    // Method : System.TypeNameParser._GetModifiers(System.SafeTypeNameParserHandle, System.Runtime.CompilerServices.ObjectHandleOnStack)
    void TypeNameParser::_GetModifiers(_::SafeTypeNameParserHandle* pTypeNameParser, _::Runtime::CompilerServices::ObjectHandleOnStack retArray)
    {
        throw 3221274624U;
    }
    
    // Method : System.TypeNameParser._GetAssemblyName(System.SafeTypeNameParserHandle, System.Runtime.CompilerServices.StringHandleOnStack)
    void TypeNameParser::_GetAssemblyName(_::SafeTypeNameParserHandle* pTypeNameParser, _::Runtime::CompilerServices::StringHandleOnStack retString)
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
