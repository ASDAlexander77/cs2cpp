#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace StubHelpers { 
    namespace _ = ::CoreLib::System::StubHelpers;
    // Method : System.StubHelpers.UriMarshaler.GetRawUriFromNative(System.IntPtr)
    string* UriMarshaler::GetRawUriFromNative(::CoreLib::System::IntPtr pUri)
    {
        throw 3221274624U;
    }
    
    // Method : System.StubHelpers.UriMarshaler.CreateNativeUriInstanceHelper(char*, int)
    ::CoreLib::System::IntPtr UriMarshaler::CreateNativeUriInstanceHelper(char16_t* rawUri, int32_t strLen)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace StubHelpers { 
    namespace _ = ::CoreLib::System::StubHelpers;
}}}
