#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Diagnostics { 
    namespace _ = ::CoreLib::System::Diagnostics;
    // Method : System.Diagnostics.Debugger.BreakInternal()
    void Debugger::BreakInternal()
    {
        throw 3221274624U;
    }
    
    // Method : System.Diagnostics.Debugger.LaunchInternal()
    bool Debugger::LaunchInternal()
    {
        throw 3221274624U;
    }
    
    // Method : System.Diagnostics.Debugger.IsAttached.get
    bool Debugger::get_IsAttached()
    {
        throw 3221274624U;
    }
    
    // Method : System.Diagnostics.Debugger.Log(int, string, string)
    void Debugger::Log(int32_t level, string* category, string* message)
    {
        throw 3221274624U;
    }
    
    // Method : System.Diagnostics.Debugger.IsLogging()
    bool Debugger::IsLogging()
    {
        throw 3221274624U;
    }
    
    // Method : System.Diagnostics.Debugger.CustomNotification(System.Diagnostics.ICustomDebuggerNotification)
    void Debugger::CustomNotification(_::ICustomDebuggerNotification* data)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Diagnostics { 
    namespace _ = ::CoreLib::System::Diagnostics;
}}}
