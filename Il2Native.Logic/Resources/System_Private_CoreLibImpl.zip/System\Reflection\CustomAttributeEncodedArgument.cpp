#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Reflection { 
    namespace _ = ::CoreLib::System::Reflection;
    // Method : System.Reflection.CustomAttributeEncodedArgument.ParseAttributeArguments(System.IntPtr, int, ref System.Reflection.CustomAttributeCtorParameter[], ref System.Reflection.CustomAttributeNamedParameter[], System.Reflection.RuntimeAssembly)
    void CustomAttributeEncodedArgument::ParseAttributeArguments_Ref_Ref(::CoreLib::System::IntPtr pCa, int32_t cCa, __array<_::CustomAttributeCtorParameter>*& CustomAttributeCtorParameters, __array<_::CustomAttributeNamedParameter>*& CustomAttributeTypedArgument, _::RuntimeAssembly* assembly)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Reflection { 
    namespace _ = ::CoreLib::System::Reflection;
}}}
