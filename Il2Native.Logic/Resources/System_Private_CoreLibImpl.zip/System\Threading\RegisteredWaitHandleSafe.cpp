#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Threading { 
    namespace _ = ::CoreLib::System::Threading;
    // Method : System.Threading.RegisteredWaitHandleSafe.WaitHandleCleanupNative(System.IntPtr)
    void RegisteredWaitHandleSafe::WaitHandleCleanupNative(::CoreLib::System::IntPtr handle)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.RegisteredWaitHandleSafe.UnregisterWaitNative(System.IntPtr, System.Runtime.InteropServices.SafeHandle)
    bool RegisteredWaitHandleSafe::UnregisterWaitNative(::CoreLib::System::IntPtr handle, ::CoreLib::System::Runtime::InteropServices::SafeHandle* waitObject)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Threading { 
    namespace _ = ::CoreLib::System::Threading;
}}}
