#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Runtime { 
    namespace _ = ::CoreLib::System::Runtime;
    // Method : System.Runtime.MemoryFailPoint.GetMemorySettings(out ulong, out ulong)
    void MemoryFailPoint::GetMemorySettings_Out_Out(uint64_t& maxGCSegmentSize, uint64_t& topOfMemory)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Runtime { 
    namespace _ = ::CoreLib::System::Runtime;
}}}
