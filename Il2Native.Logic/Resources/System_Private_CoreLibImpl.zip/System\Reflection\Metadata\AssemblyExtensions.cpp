#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Reflection { namespace Metadata { 
    namespace _ = ::CoreLib::System::Reflection::Metadata;
    // Method : System.Reflection.Metadata.AssemblyExtensions.InternalTryGetRawMetadata(System.Reflection.RuntimeAssembly, ref byte*, ref int)
    bool AssemblyExtensions::InternalTryGetRawMetadata_Ref_Ref(::CoreLib::System::Reflection::RuntimeAssembly* assembly, uint8_t*& blob, int32_t& length)
    {
        throw 3221274624U;
    }

}}}}

namespace CoreLib { namespace System { namespace Reflection { namespace Metadata { 
    namespace _ = ::CoreLib::System::Reflection::Metadata;
}}}}
