#include "System.Private.CoreLib.h"

namespace CoreLib { 
    namespace _ = ::CoreLib;
    // Method : Interop.OleAut32.SysAllocStringLen(System.IntPtr, uint)
    ::CoreLib::System::Security::SafeBSTRHandle* Interop_OleAut32::SysAllocStringLen(::CoreLib::System::IntPtr src, uint32_t len)
    {
        throw 3221274624U;
    }
    
    // Method : Interop.OleAut32.SysAllocStringLen(string, int)
    ::CoreLib::System::IntPtr Interop_OleAut32::SysAllocStringLen(string* src, int32_t len)
    {
        throw 3221274624U;
    }
    
    // Method : Interop.OleAut32.SysFreeString(System.IntPtr)
    void Interop_OleAut32::SysFreeString(::CoreLib::System::IntPtr bstr)
    {
        throw 3221274624U;
    }
    
    // Method : Interop.OleAut32.SysStringLen(System.Security.SafeBSTRHandle)
    uint32_t Interop_OleAut32::SysStringLen(::CoreLib::System::Security::SafeBSTRHandle* bstr)
    {
        throw 3221274624U;
    }
    
    // Method : Interop.OleAut32.SysStringLen(System.IntPtr)
    uint32_t Interop_OleAut32::SysStringLen(::CoreLib::System::IntPtr bstr)
    {
        throw 3221274624U;
    }

}

namespace CoreLib { 
    namespace _ = ::CoreLib;
}
