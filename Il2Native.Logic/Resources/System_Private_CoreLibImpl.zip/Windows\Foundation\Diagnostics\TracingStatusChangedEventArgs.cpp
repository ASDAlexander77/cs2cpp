#include "System.Private.CoreLib.h"

namespace CoreLib { namespace Windows { namespace Foundation { namespace Diagnostics { 
    namespace _ = ::CoreLib::Windows::Foundation::Diagnostics;
    // Method : Windows.Foundation.Diagnostics.TracingStatusChangedEventArgs.Enabled.get
    bool TracingStatusChangedEventArgs::get_Enabled()
    {
        throw 3221274624U;
    }
    
    // Method : Windows.Foundation.Diagnostics.TracingStatusChangedEventArgs.TraceLevel.get
    _::CausalityTraceLevel__enum TracingStatusChangedEventArgs::get_TraceLevel()
    {
        throw 3221274624U;
    }

}}}}

namespace CoreLib { namespace Windows { namespace Foundation { namespace Diagnostics { 
    namespace _ = ::CoreLib::Windows::Foundation::Diagnostics;
}}}}
