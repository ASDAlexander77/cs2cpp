#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.WeakReference.IsAlive.get
    bool WeakReference::get_IsAlive()
    {
        throw 3221274624U;
    }
    
    // Method : System.WeakReference.Target.get
    object* WeakReference::get_Target()
    {
        throw 3221274624U;
    }
    
    // Method : System.WeakReference.Target.set
    void WeakReference::set_Target(object* value)
    {
        throw 3221274624U;
    }
    
    // Method : System.WeakReference.~WeakReference()
    void WeakReference::Finalize()
    {
        throw 3221274624U;
    }
    
    // Method : System.WeakReference.Create(object, bool)
    void WeakReference::Create(object* target, bool trackResurrection)
    {
        throw 3221274624U;
    }
    
    // Method : System.WeakReference.IsTrackResurrection()
    bool WeakReference::IsTrackResurrection()
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
