#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Runtime { namespace InteropServices { 
    namespace _ = ::CoreLib::System::Runtime::InteropServices;
    // Method : System.Runtime.InteropServices.RuntimeEnvironment.GetModuleFileName()
    string* RuntimeEnvironment::GetModuleFileName()
    {
        throw 3221274624U;
    }

}}}}

namespace CoreLib { namespace System { namespace Runtime { namespace InteropServices { 
    namespace _ = ::CoreLib::System::Runtime::InteropServices;
}}}}
