#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.CLRConfig.GetConfigBoolValue(string)
    bool CLRConfig::GetConfigBoolValue(string* configSwitchName)
    {
		return false;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
