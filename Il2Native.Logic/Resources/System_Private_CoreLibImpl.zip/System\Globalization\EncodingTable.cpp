#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Globalization { 
    namespace _ = ::CoreLib::System::Globalization;
    // Method : System.Globalization.EncodingTable.GetEncodingData()
    _::InternalEncodingDataItem* EncodingTable::GetEncodingData()
    {
        throw 3221274624U;
    }
    
    // Method : System.Globalization.EncodingTable.GetNumEncodingItems()
    int32_t EncodingTable::GetNumEncodingItems()
    {
        throw 3221274624U;
    }
    
    // Method : System.Globalization.EncodingTable.GetCodePageData()
    _::InternalCodePageDataItem* EncodingTable::GetCodePageData()
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Globalization { 
    namespace _ = ::CoreLib::System::Globalization;
}}}
