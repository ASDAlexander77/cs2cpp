#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.Currency.FCallToDecimal(ref decimal, System.Currency)
    void Currency::FCallToDecimal_Ref(_::Decimal& result, _::Currency c)
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
