#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Resources { 
    namespace _ = ::CoreLib::System::Resources;
    // Method : System.Resources.ManifestBasedResourceGroveler.GetNeutralResourcesLanguageAttribute(System.Reflection.RuntimeAssembly, System.Runtime.CompilerServices.StringHandleOnStack, out short)
    bool ManifestBasedResourceGroveler::GetNeutralResourcesLanguageAttribute_Out(::CoreLib::System::Reflection::RuntimeAssembly* assemblyHandle, ::CoreLib::System::Runtime::CompilerServices::StringHandleOnStack cultureName, int16_t& fallbackLocation)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Resources { 
    namespace _ = ::CoreLib::System::Resources;
}}}
