#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.Variant.GetR8FromVar()
    double Variant::GetR8FromVar()
    {
        throw 3221274624U;
    }
    
    // Method : System.Variant.GetR4FromVar()
    float Variant::GetR4FromVar()
    {
        throw 3221274624U;
    }
    
    // Method : System.Variant.SetFieldsR4(float)
    void Variant::SetFieldsR4(float val)
    {
        throw 3221274624U;
    }
    
    // Method : System.Variant.SetFieldsR8(double)
    void Variant::SetFieldsR8(double val)
    {
        throw 3221274624U;
    }
    
    // Method : System.Variant.SetFieldsObject(object)
    void Variant::SetFieldsObject(object* val)
    {
        throw 3221274624U;
    }
    
    // Method : System.Variant.BoxEnum()
    object* Variant::BoxEnum()
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
