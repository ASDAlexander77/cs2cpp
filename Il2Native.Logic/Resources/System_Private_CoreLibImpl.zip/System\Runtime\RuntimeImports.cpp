#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Runtime { 
    namespace _ = ::CoreLib::System::Runtime;
    // Method : System.Runtime.RuntimeImports.RhZeroMemory(void*, ulong)
    void RuntimeImports::RhZeroMemory(void* b, uint64_t byteLength)
    {
        throw 3221274624U;
    }
    
    // Method : System.Runtime.RuntimeImports.RhBulkMoveWithWriteBarrier(ref byte, ref byte, ulong)
    void RuntimeImports::RhBulkMoveWithWriteBarrier_Ref_Ref(uint8_t& destination, uint8_t& source, uint64_t byteCount)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Runtime { 
    namespace _ = ::CoreLib::System::Runtime;
}}}
