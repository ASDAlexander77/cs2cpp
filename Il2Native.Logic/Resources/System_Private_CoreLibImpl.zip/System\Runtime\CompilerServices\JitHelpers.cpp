#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Runtime { namespace CompilerServices { 
    namespace _ = ::CoreLib::System::Runtime::CompilerServices;
    // Method : System.Runtime.CompilerServices.JitHelpers.UnsafeSetArrayElement(object[], int, object)
    void JitHelpers::UnsafeSetArrayElement(__array<object*>* target, int32_t index, object* element)
    {
        throw 3221274624U;
    }
    
#if CORECLR_DEBUG
    // Method : System.Runtime.CompilerServices.JitHelpers.IsAddressInStack(System.IntPtr)
    bool JitHelpers::IsAddressInStack(::CoreLib::System::IntPtr ptr)
    {
        throw 3221274624U;
    }
#endif

}}}}

namespace CoreLib { namespace System { namespace Runtime { namespace CompilerServices { 
    namespace _ = ::CoreLib::System::Runtime::CompilerServices;
}}}}
