#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Runtime { namespace InteropServices { 
    namespace _ = ::CoreLib::System::Runtime::InteropServices;
    // Method : System.Runtime.InteropServices.ArrayWithOffset.CalculateCount()
    int32_t ArrayWithOffset::CalculateCount()
    {
        throw 3221274624U;
    }

}}}}

namespace CoreLib { namespace System { namespace Runtime { namespace InteropServices { 
    namespace _ = ::CoreLib::System::Runtime::InteropServices;
}}}}
