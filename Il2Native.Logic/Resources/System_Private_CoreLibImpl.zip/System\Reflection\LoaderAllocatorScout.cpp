#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Reflection { 
    namespace _ = ::CoreLib::System::Reflection;
    // Method : System.Reflection.LoaderAllocatorScout.Destroy(System.IntPtr)
    bool LoaderAllocatorScout::Destroy(::CoreLib::System::IntPtr nativeLoaderAllocator)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Reflection { 
    namespace _ = ::CoreLib::System::Reflection;
}}}
