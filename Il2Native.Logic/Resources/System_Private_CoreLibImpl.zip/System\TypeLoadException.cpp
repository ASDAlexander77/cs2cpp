#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.TypeLoadException.GetTypeLoadExceptionMessage(int, System.Runtime.CompilerServices.StringHandleOnStack)
    void TypeLoadException::GetTypeLoadExceptionMessage(int32_t resourceId, _::Runtime::CompilerServices::StringHandleOnStack retString)
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
