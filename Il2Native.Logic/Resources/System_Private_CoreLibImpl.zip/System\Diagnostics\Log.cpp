#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Diagnostics { 
    namespace _ = ::CoreLib::System::Diagnostics;
    // Method : System.Diagnostics.Log.AddLogSwitch(System.Diagnostics.LogSwitch)
    void Log::AddLogSwitch(_::LogSwitch* logSwitch)
    {
        throw 3221274624U;
    }
    
    // Method : System.Diagnostics.Log.ModifyLogSwitch(int, string, string)
    void Log::ModifyLogSwitch(int32_t iNewLevel, string* strSwitchName, string* strParentName)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Diagnostics { 
    namespace _ = ::CoreLib::System::Diagnostics;
}}}
