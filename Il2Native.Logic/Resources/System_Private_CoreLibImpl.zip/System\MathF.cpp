#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.MathF.Acos(float)
    float MathF::Acos(float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Asin(float)
    float MathF::Asin(float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Atan(float)
    float MathF::Atan(float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Atan2(float, float)
    float MathF::Atan2(float y, float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Ceiling(float)
    float MathF::Ceiling(float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Cos(float)
    float MathF::Cos(float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Cosh(float)
    float MathF::Cosh(float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Exp(float)
    float MathF::Exp(float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Floor(float)
    float MathF::Floor(float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Log(float)
    float MathF::Log(float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Log10(float)
    float MathF::Log10(float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Pow(float, float)
    float MathF::Pow(float x, float y)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Round(float)
    float MathF::Round(float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Sin(float)
    float MathF::Sin(float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Sinh(float)
    float MathF::Sinh(float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Sqrt(float)
    float MathF::Sqrt(float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Tan(float)
    float MathF::Tan(float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.Tanh(float)
    float MathF::Tanh(float x)
    {
        throw 3221274624U;
    }
    
    // Method : System.MathF.SplitFractionSingle(float*)
    float MathF::SplitFractionSingle(float* x)
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
