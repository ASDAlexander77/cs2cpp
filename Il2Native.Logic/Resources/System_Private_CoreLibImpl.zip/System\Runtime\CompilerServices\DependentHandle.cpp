#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Runtime { namespace CompilerServices { 
    namespace _ = ::CoreLib::System::Runtime::CompilerServices;
    // Method : System.Runtime.CompilerServices.DependentHandle.nInitialize(object, object)
    ::CoreLib::System::IntPtr DependentHandle::nInitialize(object* primary, object* secondary)
    {
        throw 3221274624U;
    }
    
    // Method : System.Runtime.CompilerServices.DependentHandle.nGetPrimary(System.IntPtr)
    object* DependentHandle::nGetPrimary(::CoreLib::System::IntPtr dependentHandle)
    {
        throw 3221274624U;
    }
    
    // Method : System.Runtime.CompilerServices.DependentHandle.nGetPrimaryAndSecondary(System.IntPtr, out object)
    object* DependentHandle::nGetPrimaryAndSecondary_Out(::CoreLib::System::IntPtr dependentHandle, object*& secondary)
    {
        throw 3221274624U;
    }
    
    // Method : System.Runtime.CompilerServices.DependentHandle.nSetPrimary(System.IntPtr, object)
    void DependentHandle::nSetPrimary(::CoreLib::System::IntPtr dependentHandle, object* primary)
    {
        throw 3221274624U;
    }
    
    // Method : System.Runtime.CompilerServices.DependentHandle.nSetSecondary(System.IntPtr, object)
    void DependentHandle::nSetSecondary(::CoreLib::System::IntPtr dependentHandle, object* secondary)
    {
        throw 3221274624U;
    }
    
    // Method : System.Runtime.CompilerServices.DependentHandle.nFree(System.IntPtr)
    void DependentHandle::nFree(::CoreLib::System::IntPtr dependentHandle)
    {
        throw 3221274624U;
    }

}}}}

namespace CoreLib { namespace System { namespace Runtime { namespace CompilerServices { 
    namespace _ = ::CoreLib::System::Runtime::CompilerServices;
}}}}
