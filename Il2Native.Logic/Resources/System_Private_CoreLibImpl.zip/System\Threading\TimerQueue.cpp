#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Threading { 
    namespace _ = ::CoreLib::System::Threading;
    // Method : System.Threading.TimerQueue.CreateAppDomainTimer(uint)
    _::TimerQueue_AppDomainTimerSafeHandle* TimerQueue::CreateAppDomainTimer(uint32_t dueTime)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.TimerQueue.ChangeAppDomainTimer(System.Threading.TimerQueue.AppDomainTimerSafeHandle, uint)
    bool TimerQueue::ChangeAppDomainTimer(_::TimerQueue_AppDomainTimerSafeHandle* handle, uint32_t dueTime)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.TimerQueue.DeleteAppDomainTimer(System.IntPtr)
    bool TimerQueue::DeleteAppDomainTimer(::CoreLib::System::IntPtr handle)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Threading { 
    namespace _ = ::CoreLib::System::Threading;
}}}
