#include "System.Private.CoreLib.h"

namespace CoreLib { 
    namespace _ = ::CoreLib;
    // Method : Interop.BCrypt.BCryptGenRandom(System.IntPtr, byte*, int, int)
    int32_t Interop_BCrypt::BCryptGenRandom(::CoreLib::System::IntPtr hAlgorithm, uint8_t* pbBuffer, int32_t cbBuffer, int32_t dwFlags)
    {
        throw 3221274624U;
    }

}

namespace CoreLib { 
    namespace _ = ::CoreLib;
}
