#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Runtime { namespace InteropServices { namespace WindowsRuntime { 
    namespace _ = ::CoreLib::System::Runtime::InteropServices::WindowsRuntime;
    // Method : System.Runtime.InteropServices.WindowsRuntime.WindowsRuntimeBufferHelper.StoreOverlappedPtrInCCW(System.Runtime.CompilerServices.ObjectHandleOnStack, System.Threading.NativeOverlapped*)
    void WindowsRuntimeBufferHelper::StoreOverlappedPtrInCCW(::CoreLib::System::Runtime::CompilerServices::ObjectHandleOnStack windowsRuntimeBuffer, ::CoreLib::System::Threading::NativeOverlapped* overlapped)
    {
        throw 3221274624U;
    }

}}}}}

namespace CoreLib { namespace System { namespace Runtime { namespace InteropServices { namespace WindowsRuntime { 
    namespace _ = ::CoreLib::System::Runtime::InteropServices::WindowsRuntime;
}}}}}
