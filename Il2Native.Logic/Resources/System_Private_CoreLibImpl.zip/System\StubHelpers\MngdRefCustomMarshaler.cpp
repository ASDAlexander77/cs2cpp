#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace StubHelpers { 
    namespace _ = ::CoreLib::System::StubHelpers;
    // Method : System.StubHelpers.MngdRefCustomMarshaler.CreateMarshaler(System.IntPtr, System.IntPtr)
    void MngdRefCustomMarshaler::CreateMarshaler(::CoreLib::System::IntPtr pMarshalState, ::CoreLib::System::IntPtr pCMHelper)
    {
        throw 3221274624U;
    }
    
    // Method : System.StubHelpers.MngdRefCustomMarshaler.ConvertContentsToNative(System.IntPtr, ref object, System.IntPtr)
    void MngdRefCustomMarshaler::ConvertContentsToNative_Ref(::CoreLib::System::IntPtr pMarshalState, object*& pManagedHome, ::CoreLib::System::IntPtr pNativeHome)
    {
        throw 3221274624U;
    }
    
    // Method : System.StubHelpers.MngdRefCustomMarshaler.ConvertContentsToManaged(System.IntPtr, ref object, System.IntPtr)
    void MngdRefCustomMarshaler::ConvertContentsToManaged_Ref(::CoreLib::System::IntPtr pMarshalState, object*& pManagedHome, ::CoreLib::System::IntPtr pNativeHome)
    {
        throw 3221274624U;
    }
    
    // Method : System.StubHelpers.MngdRefCustomMarshaler.ClearNative(System.IntPtr, ref object, System.IntPtr)
    void MngdRefCustomMarshaler::ClearNative_Ref(::CoreLib::System::IntPtr pMarshalState, object*& pManagedHome, ::CoreLib::System::IntPtr pNativeHome)
    {
        throw 3221274624U;
    }
    
    // Method : System.StubHelpers.MngdRefCustomMarshaler.ClearManaged(System.IntPtr, ref object, System.IntPtr)
    void MngdRefCustomMarshaler::ClearManaged_Ref(::CoreLib::System::IntPtr pMarshalState, object*& pManagedHome, ::CoreLib::System::IntPtr pNativeHome)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace StubHelpers { 
    namespace _ = ::CoreLib::System::StubHelpers;
}}}
