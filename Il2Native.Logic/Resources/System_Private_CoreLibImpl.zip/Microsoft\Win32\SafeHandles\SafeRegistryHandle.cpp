#include "System.Private.CoreLib.h"

namespace CoreLib { namespace Microsoft { namespace Win32 { namespace SafeHandles { 
    namespace _ = ::CoreLib::Microsoft::Win32::SafeHandles;
    // Method : Microsoft.Win32.SafeHandles.SafeRegistryHandle.RegCloseKey(System.IntPtr)
    int32_t SafeRegistryHandle::RegCloseKey(::CoreLib::System::IntPtr hKey)
    {
        throw 3221274624U;
    }

}}}}

namespace CoreLib { namespace Microsoft { namespace Win32 { namespace SafeHandles { 
    namespace _ = ::CoreLib::Microsoft::Win32::SafeHandles;
}}}}
