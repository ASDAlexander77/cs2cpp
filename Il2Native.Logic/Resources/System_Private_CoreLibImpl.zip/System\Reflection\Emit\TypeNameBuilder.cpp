#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Reflection { namespace Emit { 
    namespace _ = ::CoreLib::System::Reflection::Emit;
    // Method : System.Reflection.Emit.TypeNameBuilder.CreateTypeNameBuilder()
    ::CoreLib::System::IntPtr TypeNameBuilder::CreateTypeNameBuilder()
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.Emit.TypeNameBuilder.ReleaseTypeNameBuilder(System.IntPtr)
    void TypeNameBuilder::ReleaseTypeNameBuilder(::CoreLib::System::IntPtr pAQN)
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.Emit.TypeNameBuilder.OpenGenericArguments(System.IntPtr)
    void TypeNameBuilder::OpenGenericArguments(::CoreLib::System::IntPtr tnb)
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.Emit.TypeNameBuilder.CloseGenericArguments(System.IntPtr)
    void TypeNameBuilder::CloseGenericArguments(::CoreLib::System::IntPtr tnb)
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.Emit.TypeNameBuilder.OpenGenericArgument(System.IntPtr)
    void TypeNameBuilder::OpenGenericArgument(::CoreLib::System::IntPtr tnb)
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.Emit.TypeNameBuilder.CloseGenericArgument(System.IntPtr)
    void TypeNameBuilder::CloseGenericArgument(::CoreLib::System::IntPtr tnb)
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.Emit.TypeNameBuilder.AddName(System.IntPtr, string)
    void TypeNameBuilder::AddName(::CoreLib::System::IntPtr tnb, string* name)
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.Emit.TypeNameBuilder.AddPointer(System.IntPtr)
    void TypeNameBuilder::AddPointer(::CoreLib::System::IntPtr tnb)
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.Emit.TypeNameBuilder.AddByRef(System.IntPtr)
    void TypeNameBuilder::AddByRef(::CoreLib::System::IntPtr tnb)
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.Emit.TypeNameBuilder.AddSzArray(System.IntPtr)
    void TypeNameBuilder::AddSzArray(::CoreLib::System::IntPtr tnb)
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.Emit.TypeNameBuilder.AddArray(System.IntPtr, int)
    void TypeNameBuilder::AddArray(::CoreLib::System::IntPtr tnb, int32_t rank)
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.Emit.TypeNameBuilder.AddAssemblySpec(System.IntPtr, string)
    void TypeNameBuilder::AddAssemblySpec(::CoreLib::System::IntPtr tnb, string* assemblySpec)
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.Emit.TypeNameBuilder.ToString(System.IntPtr, System.Runtime.CompilerServices.StringHandleOnStack)
    void TypeNameBuilder::ToString(::CoreLib::System::IntPtr tnb, ::CoreLib::System::Runtime::CompilerServices::StringHandleOnStack retString)
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.Emit.TypeNameBuilder.Clear(System.IntPtr)
    void TypeNameBuilder::Clear(::CoreLib::System::IntPtr tnb)
    {
        throw 3221274624U;
    }

}}}}

namespace CoreLib { namespace System { namespace Reflection { namespace Emit { 
    namespace _ = ::CoreLib::System::Reflection::Emit;
}}}}
