#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.Enum.InternalCompareTo(object, object)
    int32_t Enum::InternalCompareTo(object* o1, object* o2)
    {
        throw 3221274624U;
    }
    
    // Method : System.Enum.InternalGetUnderlyingType(System.RuntimeType)
    _::RuntimeType* Enum::InternalGetUnderlyingType(_::RuntimeType* enumType)
    {
        throw 3221274624U;
    }
    
    // Method : System.Enum.GetEnumValuesAndNames(System.RuntimeTypeHandle, System.Runtime.CompilerServices.ObjectHandleOnStack, System.Runtime.CompilerServices.ObjectHandleOnStack, bool)
    void Enum::GetEnumValuesAndNames(_::RuntimeTypeHandle enumType, _::Runtime::CompilerServices::ObjectHandleOnStack values, _::Runtime::CompilerServices::ObjectHandleOnStack names, bool getNames)
    {
        throw 3221274624U;
    }
    
    // Method : System.Enum.InternalBoxEnum(System.RuntimeType, long)
    object* Enum::InternalBoxEnum(_::RuntimeType* enumType, int64_t value)
    {
        throw 3221274624U;
    }
    
    // Method : System.Enum.InternalHasFlag(System.Enum)
    bool Enum::InternalHasFlag(_::Enum* flags)
    {
        throw 3221274624U;
    }
    
    // Method : System.Enum.InternalGetCorElementType()
    _::Reflection::CorElementType__enum Enum::InternalGetCorElementType()
    {
        throw 3221274624U;
    }
    
    // Method : System.Enum.Equals(object)
    bool Enum::Equals(object* obj)
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
