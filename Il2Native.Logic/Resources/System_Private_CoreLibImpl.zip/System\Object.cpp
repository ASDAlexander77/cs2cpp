#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : object.GetType()
    _::Type* Object::GetType()
    {
        throw 3221274624U;
    }
    
    // Method : object.MemberwiseClone()
    object* Object::MemberwiseClone()
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
