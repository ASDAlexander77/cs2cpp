#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Diagnostics { 
    namespace _ = ::CoreLib::System::Diagnostics;
    // Method : System.Diagnostics.StackTrace.GetStackFramesInternal(System.Diagnostics.StackFrameHelper, int, bool, System.Exception)
    void StackTrace::GetStackFramesInternal(_::StackFrameHelper* sfh, int32_t iSkip, bool fNeedFileInfo, ::CoreLib::System::Exception* e)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Diagnostics { 
    namespace _ = ::CoreLib::System::Diagnostics;
}}}
