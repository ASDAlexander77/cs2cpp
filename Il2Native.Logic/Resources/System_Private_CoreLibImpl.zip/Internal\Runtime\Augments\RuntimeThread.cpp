#include "System.Private.CoreLib.h"

namespace CoreLib { namespace Internal { namespace Runtime { namespace Augments { 
    namespace _ = ::CoreLib::Internal::Runtime::Augments;
    // Method : Internal.Runtime.Augments.RuntimeThread.IsAlive.get
    bool RuntimeThread::get_IsAlive()
    {
        throw 3221274624U;
    }
    
    // Method : Internal.Runtime.Augments.RuntimeThread.IsBackgroundNative()
    bool RuntimeThread::IsBackgroundNative()
    {
        throw 3221274624U;
    }
    
    // Method : Internal.Runtime.Augments.RuntimeThread.SetBackgroundNative(bool)
    void RuntimeThread::SetBackgroundNative(bool isBackground)
    {
        throw 3221274624U;
    }
    
    // Method : Internal.Runtime.Augments.RuntimeThread.IsThreadPoolThread.get
    bool RuntimeThread::get_IsThreadPoolThread()
    {
        throw 3221274624U;
    }
    
    // Method : Internal.Runtime.Augments.RuntimeThread.GetPriorityNative()
    int32_t RuntimeThread::GetPriorityNative()
    {
        throw 3221274624U;
    }
    
    // Method : Internal.Runtime.Augments.RuntimeThread.SetPriorityNative(int)
    void RuntimeThread::SetPriorityNative(int32_t priority)
    {
        throw 3221274624U;
    }
    
    // Method : Internal.Runtime.Augments.RuntimeThread.GetThreadStateNative()
    int32_t RuntimeThread::GetThreadStateNative()
    {
        throw 3221274624U;
    }
    
    // Method : Internal.Runtime.Augments.RuntimeThread.GetApartmentStateNative()
    int32_t RuntimeThread::GetApartmentStateNative()
    {
        throw 3221274624U;
    }
    
    // Method : Internal.Runtime.Augments.RuntimeThread.SetApartmentStateNative(int, bool)
    int32_t RuntimeThread::SetApartmentStateNative(int32_t state, bool fireMDAOnMismatch)
    {
        throw 3221274624U;
    }
    
    // Method : Internal.Runtime.Augments.RuntimeThread.DisableComObjectEagerCleanup()
    void RuntimeThread::DisableComObjectEagerCleanup()
    {
        throw 3221274624U;
    }
    
    // Method : Internal.Runtime.Augments.RuntimeThread.InterruptInternal()
    void RuntimeThread::InterruptInternal()
    {
        throw 3221274624U;
    }
    
    // Method : Internal.Runtime.Augments.RuntimeThread.JoinInternal(int)
    bool RuntimeThread::JoinInternal(int32_t millisecondsTimeout)
    {
        throw 3221274624U;
    }

}}}}

namespace CoreLib { namespace Internal { namespace Runtime { namespace Augments { 
    namespace _ = ::CoreLib::Internal::Runtime::Augments;
}}}}
