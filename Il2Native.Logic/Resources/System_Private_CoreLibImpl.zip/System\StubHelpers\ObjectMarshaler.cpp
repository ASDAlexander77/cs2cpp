#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace StubHelpers { 
    namespace _ = ::CoreLib::System::StubHelpers;
    // Method : System.StubHelpers.ObjectMarshaler.ConvertToNative(object, System.IntPtr)
    void ObjectMarshaler::ConvertToNative(object* objSrc, ::CoreLib::System::IntPtr pDstVariant)
    {
        throw 3221274624U;
    }
    
    // Method : System.StubHelpers.ObjectMarshaler.ConvertToManaged(System.IntPtr)
    object* ObjectMarshaler::ConvertToManaged(::CoreLib::System::IntPtr pSrcVariant)
    {
        throw 3221274624U;
    }
    
    // Method : System.StubHelpers.ObjectMarshaler.ClearNative(System.IntPtr)
    void ObjectMarshaler::ClearNative(::CoreLib::System::IntPtr pVariant)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace StubHelpers { 
    namespace _ = ::CoreLib::System::StubHelpers;
}}}
