#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Threading { 
    namespace _ = ::CoreLib::System::Threading;
    // Method : System.Threading.SynchronizationContext.WaitHelperNative(System.IntPtr[], bool, int)
    int32_t SynchronizationContext::WaitHelperNative(__array<::CoreLib::System::IntPtr>* waitHandles, bool waitAll, int32_t millisecondsTimeout)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.SynchronizationContext.GetWinRTDispatcherForCurrentThread()
    object* SynchronizationContext::GetWinRTDispatcherForCurrentThread()
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Threading { 
    namespace _ = ::CoreLib::System::Threading;
}}}
