#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.Buffer.BlockCopy(System.Array, int, System.Array, int, int)
    void Buffer::BlockCopy(_::Array* src, int32_t srcOffset, _::Array* dst, int32_t dstOffset, int32_t count)
    {
        throw 3221274624U;
    }
    
    // Method : System.Buffer.InternalBlockCopy(System.Array, int, System.Array, int, int)
    void Buffer::InternalBlockCopy(_::Array* src, int32_t srcOffsetBytes, _::Array* dst, int32_t dstOffsetBytes, int32_t byteCount)
    {
        throw 3221274624U;
    }
    
    // Method : System.Buffer.IsPrimitiveTypeArray(System.Array)
    bool Buffer::IsPrimitiveTypeArray(_::Array* array)
    {
        throw 3221274624U;
    }
    
    // Method : System.Buffer._GetByte(System.Array, int)
    uint8_t Buffer::_GetByte(_::Array* array, int32_t index)
    {
        throw 3221274624U;
    }
    
    // Method : System.Buffer._SetByte(System.Array, int, byte)
    void Buffer::_SetByte(_::Array* array, int32_t index, uint8_t value)
    {
        throw 3221274624U;
    }
    
    // Method : System.Buffer._ByteLength(System.Array)
    int32_t Buffer::_ByteLength(_::Array* array)
    {
        throw 3221274624U;
    }
    
    // Method : System.Buffer.__Memmove(byte*, byte*, ulong)
    void Buffer::__Memmove(uint8_t* dest, uint8_t* src, uint64_t len)
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
