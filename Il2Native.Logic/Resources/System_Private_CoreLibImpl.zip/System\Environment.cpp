#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.Environment.TickCount.get
    int32_t Environment::get_TickCount()
    {
        throw 3221274624U;
    }
    
    // Method : System.Environment._Exit(int)
    void Environment::_Exit(int32_t exitCode)
    {
        throw 3221274624U;
    }
    
    // Method : System.Environment.ExitCode.get
    int32_t Environment::get_ExitCode()
    {
        throw 3221274624U;
    }
    
    // Method : System.Environment.ExitCode.set
    void Environment::set_ExitCode(int32_t value)
    {
        throw 3221274624U;
    }
    
    // Method : System.Environment.FailFast(string)
    void Environment::FailFast(string* message)
    {
        throw 3221274624U;
    }
    
    // Method : System.Environment.FailFast(string, System.Exception)
    void Environment::FailFast(string* message, _::Exception* exception)
    {
        throw 3221274624U;
    }
    
    // Method : System.Environment.GetProcessorCount()
    int32_t Environment::GetProcessorCount()
    {
        throw 3221274624U;
    }
    
    // Method : System.Environment.GetCommandLineArgsNative()
    __array<string*>* Environment::GetCommandLineArgsNative()
    {
        throw 3221274624U;
    }
    
    // Method : System.Environment.WinRTSupported()
    bool Environment::WinRTSupported()
    {
        throw 3221274624U;
    }
    
    // Method : System.Environment.HasShutdownStarted.get
    bool Environment::get_HasShutdownStarted()
    {
        throw 3221274624U;
    }
    
    // Method : System.Environment.CurrentProcessorNumber.get
    int32_t Environment::get_CurrentProcessorNumber()
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
