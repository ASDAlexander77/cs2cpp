#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.AppDomainManager.GetEntryAssembly(System.Runtime.CompilerServices.ObjectHandleOnStack)
    void AppDomainManager::GetEntryAssembly(_::Runtime::CompilerServices::ObjectHandleOnStack retAssembly)
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
