#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.ValueType.CanCompareBits(object)
    bool ValueType::CanCompareBits(object* obj)
    {
        throw 3221274624U;
    }
    
    // Method : System.ValueType.FastEqualsCheck(object, object)
    bool ValueType::FastEqualsCheck(object* a, object* b)
    {
        throw 3221274624U;
    }
    
    // Method : System.ValueType.GetHashCode()
    int32_t ValueType::GetHashCode()
    {
        throw 3221274624U;
    }
    
    // Method : System.ValueType.GetHashCodeOfPtr(System.IntPtr)
    int32_t ValueType::GetHashCodeOfPtr(_::IntPtr ptr)
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
