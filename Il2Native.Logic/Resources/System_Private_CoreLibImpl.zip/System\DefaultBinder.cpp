#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.DefaultBinder.CanConvertPrimitive(System.RuntimeType, System.RuntimeType)
    bool DefaultBinder::CanConvertPrimitive(_::RuntimeType* source, _::RuntimeType* target)
    {
        throw 3221274624U;
    }
    
    // Method : System.DefaultBinder.CanConvertPrimitiveObjectToType(object, System.RuntimeType)
    bool DefaultBinder::CanConvertPrimitiveObjectToType(object* source, _::RuntimeType* type)
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
