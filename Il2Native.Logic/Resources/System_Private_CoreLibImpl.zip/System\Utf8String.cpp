#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.Utf8String.EqualsCaseSensitive(void*, void*, int)
    bool Utf8String::EqualsCaseSensitive(void* szLhs, void* szRhs, int32_t cSz)
    {
        throw 3221274624U;
    }
    
    // Method : System.Utf8String.EqualsCaseInsensitive(void*, void*, int)
    bool Utf8String::EqualsCaseInsensitive(void* szLhs, void* szRhs, int32_t cSz)
    {
        throw 3221274624U;
    }
    
    // Method : System.Utf8String.HashCaseInsensitive(void*, int)
    uint32_t Utf8String::HashCaseInsensitive(void* sz, int32_t cSz)
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
