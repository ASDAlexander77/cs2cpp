#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Globalization { 
    namespace _ = ::CoreLib::System::Globalization;
    // Method : System.Globalization.CompareInfo.InternalGetGlobalizedHashCode(System.IntPtr, string, string, int, int, long)
    int32_t CompareInfo::InternalGetGlobalizedHashCode(::CoreLib::System::IntPtr handle, string* localeName, string* source, int32_t length, int32_t dwFlags, int64_t additionalEntropy)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Globalization { 
    namespace _ = ::CoreLib::System::Globalization;
}}}
