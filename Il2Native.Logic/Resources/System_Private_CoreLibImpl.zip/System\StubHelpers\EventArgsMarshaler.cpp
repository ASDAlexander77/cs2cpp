#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace StubHelpers { 
    namespace _ = ::CoreLib::System::StubHelpers;
    // Method : System.StubHelpers.EventArgsMarshaler.CreateNativePCEventArgsInstance(string)
    ::CoreLib::System::IntPtr EventArgsMarshaler::CreateNativePCEventArgsInstance(string* name)
    {
        throw 3221274624U;
    }
    
    // Method : System.StubHelpers.EventArgsMarshaler.CreateNativeNCCEventArgsInstanceHelper(int, System.IntPtr, System.IntPtr, int, int)
    ::CoreLib::System::IntPtr EventArgsMarshaler::CreateNativeNCCEventArgsInstanceHelper(int32_t action, ::CoreLib::System::IntPtr newItem, ::CoreLib::System::IntPtr oldItem, int32_t newIndex, int32_t oldIndex)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace StubHelpers { 
    namespace _ = ::CoreLib::System::StubHelpers;
}}}
