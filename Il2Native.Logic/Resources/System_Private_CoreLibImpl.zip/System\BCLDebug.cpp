#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.BCLDebug.GetRegistryLoggingValues(out bool, out bool, out int, out bool, out bool, out bool)
    int32_t BCLDebug::GetRegistryLoggingValues_Out_Out_Out_Out_Out_Out(bool& loggingEnabled, bool& logToConsole, int32_t& logLevel, bool& perfWarnings, bool& correctnessWarnings, bool& safeHandleStackTraces)
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
