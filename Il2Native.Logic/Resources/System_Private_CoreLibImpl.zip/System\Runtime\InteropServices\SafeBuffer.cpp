#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Runtime { namespace InteropServices { 
    namespace _ = ::CoreLib::System::Runtime::InteropServices;
    // Method : System.Runtime.InteropServices.SafeBuffer.PtrToStructureNative(byte*, System.TypedReference, uint)
    void SafeBuffer::PtrToStructureNative(uint8_t* ptr, ::CoreLib::System::TypedReference structure, uint32_t sizeofT)
    {
        throw 3221274624U;
    }
    
    // Method : System.Runtime.InteropServices.SafeBuffer.StructureToPtrNative(System.TypedReference, byte*, uint)
    void SafeBuffer::StructureToPtrNative(::CoreLib::System::TypedReference structure, uint8_t* ptr, uint32_t sizeofT)
    {
        throw 3221274624U;
    }

}}}}

namespace CoreLib { namespace System { namespace Runtime { namespace InteropServices { 
    namespace _ = ::CoreLib::System::Runtime::InteropServices;
}}}}
