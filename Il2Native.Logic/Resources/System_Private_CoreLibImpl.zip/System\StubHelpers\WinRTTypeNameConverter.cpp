#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace StubHelpers { 
    namespace _ = ::CoreLib::System::StubHelpers;
    // Method : System.StubHelpers.WinRTTypeNameConverter.ConvertToWinRTTypeName(System.Type, out bool)
    string* WinRTTypeNameConverter::ConvertToWinRTTypeName_Out(::CoreLib::System::Type* managedType, bool& isPrimitive)
    {
        throw 3221274624U;
    }
    
    // Method : System.StubHelpers.WinRTTypeNameConverter.GetTypeFromWinRTTypeName(string, out bool)
    ::CoreLib::System::Type* WinRTTypeNameConverter::GetTypeFromWinRTTypeName_Out(string* typeName, bool& isPrimitive)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace StubHelpers { 
    namespace _ = ::CoreLib::System::StubHelpers;
}}}
