#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.AppDomain.nGetAppXFlags()
    _::AppDomain_APPX_FLAGS__enum AppDomain::nGetAppXFlags()
    {
        throw 3221274624U;
    }
    
    // Method : System.AppDomain.nGetAssemblies(bool)
    __array<_::Reflection::Assembly*>* AppDomain::nGetAssemblies(bool forIntrospection)
    {
        throw 3221274624U;
    }
    
    // Method : System.AppDomain.IsUnloadingForcedFinalize()
    bool AppDomain::IsUnloadingForcedFinalize()
    {
        throw 3221274624U;
    }
    
    // Method : System.AppDomain.IsFinalizingForUnload()
    bool AppDomain::IsFinalizingForUnload()
    {
        throw 3221274624U;
    }
    
    // Method : System.AppDomain.PublishAnonymouslyHostedDynamicMethodsAssembly(System.Reflection.RuntimeAssembly)
    void AppDomain::PublishAnonymouslyHostedDynamicMethodsAssembly(_::Reflection::RuntimeAssembly* assemblyHandle)
    {
        throw 3221274624U;
    }
    
    // Method : System.AppDomain.GetCurrentThreadId()
    int32_t AppDomain::GetCurrentThreadId()
    {
        throw 3221274624U;
    }
    
    // Method : System.AppDomain.nCreateContext()
    void AppDomain::nCreateContext()
    {
        throw 3221274624U;
    }
    
    // Method : System.AppDomain.nSetupBindingPaths(string, string, string, string, string)
    void AppDomain::nSetupBindingPaths(string* trustedPlatformAssemblies, string* platformResourceRoots, string* appPath, string* appNiPaths, string* appLocalWinMD)
    {
        throw 3221274624U;
    }
    
    // Method : System.AppDomain.nGetFriendlyName()
    string* AppDomain::nGetFriendlyName()
    {
        throw 3221274624U;
    }
    
    // Method : System.AppDomain.nSetNativeDllSearchDirectories(string)
    void AppDomain::nSetNativeDllSearchDirectories(string* paths)
    {
        throw 3221274624U;
    }
    
    // Method : System.AppDomain.nSetupFriendlyName(string)
    void AppDomain::nSetupFriendlyName(string* friendlyName)
    {
        throw 3221274624U;
    }
    
    // Method : System.AppDomain.IsStringInterned(string)
    string* AppDomain::IsStringInterned(string* str)
    {
        throw 3221274624U;
    }
    
    // Method : System.AppDomain.GetOrInternString(string)
    string* AppDomain::GetOrInternString(string* str)
    {
        throw 3221274624U;
    }
    
    // Method : System.AppDomain.GetId()
    int32_t AppDomain::GetId()
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
