#include "System.Private.CoreLib.h"

namespace CoreLib { namespace Microsoft { namespace Win32 { 
    namespace _ = ::CoreLib::Microsoft::Win32;
    // Method : Microsoft.Win32.OAVariantLib.ChangeTypeEx(ref System.Variant, ref System.Variant, int, System.IntPtr, int, short)
    void OAVariantLib::ChangeTypeEx_Ref_Ref(::CoreLib::System::Variant& result, ::CoreLib::System::Variant& source, int32_t lcid, ::CoreLib::System::IntPtr typeHandle, int32_t cvType, int16_t flags)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace Microsoft { namespace Win32 { 
    namespace _ = ::CoreLib::Microsoft::Win32;
}}}
