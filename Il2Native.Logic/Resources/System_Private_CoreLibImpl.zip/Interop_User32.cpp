#include "System.Private.CoreLib.h"

namespace CoreLib { 
    namespace _ = ::CoreLib;
    // Method : Interop.User32.SendMessageTimeout(System.IntPtr, int, System.IntPtr, string, int, int, System.IntPtr)
    ::CoreLib::System::IntPtr Interop_User32::SendMessageTimeout(::CoreLib::System::IntPtr hWnd, int32_t msg, ::CoreLib::System::IntPtr wParam, string* lParam, int32_t flags, int32_t timeout, ::CoreLib::System::IntPtr pdwResult)
    {
        throw 3221274624U;
    }

}

namespace CoreLib { 
    namespace _ = ::CoreLib;
}
