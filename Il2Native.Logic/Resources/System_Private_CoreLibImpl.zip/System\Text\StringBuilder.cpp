#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Text { 
    namespace _ = ::CoreLib::System::Text;
    // Method : System.Text.StringBuilder.ReplaceBufferInternal(char*, int)
    void StringBuilder::ReplaceBufferInternal(char16_t* newBuffer, int32_t newLength)
    {
        throw 3221274624U;
    }
    
    // Method : System.Text.StringBuilder.ReplaceBufferAnsiInternal(sbyte*, int)
    void StringBuilder::ReplaceBufferAnsiInternal(int8_t* newBuffer, int32_t newLength)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Text { 
    namespace _ = ::CoreLib::System::Text;
}}}
