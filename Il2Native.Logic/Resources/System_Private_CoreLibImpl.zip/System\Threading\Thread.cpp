#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Threading { 
    namespace _ = ::CoreLib::System::Threading;
    // Method : System.Threading.Thread.ManagedThreadId.get
    int32_t Thread::get_ManagedThreadId()
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Thread.StartInternal(ref System.Threading.StackCrawlMark)
    void Thread::StartInternal_Ref(_::StackCrawlMark__enum& stackMark)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Thread.InternalGetCurrentThread()
    ::CoreLib::System::IntPtr Thread::InternalGetCurrentThread()
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Thread.SleepInternal(int)
    void Thread::SleepInternal(int32_t millisecondsTimeout)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Thread.SpinWaitInternal(int)
    void Thread::SpinWaitInternal(int32_t iterations)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Thread.YieldInternal()
    bool Thread::YieldInternal()
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Thread.GetCurrentThreadNative()
    _::Thread* Thread::GetCurrentThreadNative()
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Thread.SetStart(System.Delegate, int)
    void Thread::SetStart(::CoreLib::System::Delegate* start, int32_t maxStackSize)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Thread.InternalFinalize()
    void Thread::InternalFinalize()
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Thread.StartupSetApartmentStateInternal()
    void Thread::StartupSetApartmentStateInternal()
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Thread.nativeInitCultureAccessors()
    void Thread::nativeInitCultureAccessors()
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Thread.GetDomainInternal()
    ::CoreLib::System::AppDomain* Thread::GetDomainInternal()
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Thread.GetFastDomainInternal()
    ::CoreLib::System::AppDomain* Thread::GetFastDomainInternal()
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.Thread.InformThreadNameChange(System.Threading.ThreadHandle, string, int)
    void Thread::InformThreadNameChange(_::ThreadHandle t, string* name, int32_t len)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Threading { 
    namespace _ = ::CoreLib::System::Threading;
}}}
