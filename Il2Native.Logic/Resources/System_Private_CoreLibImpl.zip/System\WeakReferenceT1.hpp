namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.WeakReference<T>.Target.get
    template <typename T> 
    T WeakReferenceT1<T>::get_Target()
    {
        throw 3221274624U;
    }
    
    // Method : System.WeakReference<T>.Target.set
    template <typename T> 
    void WeakReferenceT1<T>::set_Target(T value)
    {
        throw 3221274624U;
    }
    
    // Method : System.WeakReference<T>.~WeakReference()
    template <typename T> 
    void WeakReferenceT1<T>::Finalize()
    {
        throw 3221274624U;
    }
    
    // Method : System.WeakReference<T>.Create(T, bool)
    template <typename T> 
    void WeakReferenceT1<T>::Create(T target, bool trackResurrection)
    {
        throw 3221274624U;
    }
    
    // Method : System.WeakReference<T>.IsTrackResurrection()
    template <typename T> 
    bool WeakReferenceT1<T>::IsTrackResurrection()
    {
        throw 3221274624U;
    }

}}
namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
