#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace IO { 
    namespace _ = ::CoreLib::System::IO;
    // Method : System.IO.FileLoadException.GetFileLoadExceptionMessage(int, System.Runtime.CompilerServices.StringHandleOnStack)
    void FileLoadException::GetFileLoadExceptionMessage(int32_t hResult, ::CoreLib::System::Runtime::CompilerServices::StringHandleOnStack retString)
    {
        throw 3221274624U;
    }
    
    // Method : System.IO.FileLoadException.GetMessageForHR(int, System.Runtime.CompilerServices.StringHandleOnStack)
    void FileLoadException::GetMessageForHR(int32_t hresult, ::CoreLib::System::Runtime::CompilerServices::StringHandleOnStack retString)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace IO { 
    namespace _ = ::CoreLib::System::IO;
}}}
