#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
    // Method : System.Math.Acos(double)
    double Math::Acos(double d)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Asin(double)
    double Math::Asin(double d)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Atan(double)
    double Math::Atan(double d)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Atan2(double, double)
    double Math::Atan2(double y, double x)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Ceiling(double)
    double Math::Ceiling(double a)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Cos(double)
    double Math::Cos(double d)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Cosh(double)
    double Math::Cosh(double value)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Floor(double)
    double Math::Floor(double d)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Sin(double)
    double Math::Sin(double a)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Tan(double)
    double Math::Tan(double a)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Sinh(double)
    double Math::Sinh(double value)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Tanh(double)
    double Math::Tanh(double value)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Round(double)
    double Math::Round(double a)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.SplitFractionDouble(double*)
    double Math::SplitFractionDouble(double* value)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Sqrt(double)
    double Math::Sqrt(double d)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Log(double)
    double Math::Log(double d)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Log10(double)
    double Math::Log10(double d)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Exp(double)
    double Math::Exp(double d)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Pow(double, double)
    double Math::Pow(double x, double y)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Abs(float)
    float Math::Abs(float value)
    {
        throw 3221274624U;
    }
    
    // Method : System.Math.Abs(double)
    double Math::Abs(double value)
    {
        throw 3221274624U;
    }

}}

namespace CoreLib { namespace System { 
    namespace _ = ::CoreLib::System;
}}
