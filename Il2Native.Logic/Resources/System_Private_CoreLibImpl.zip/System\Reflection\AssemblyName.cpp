#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Reflection { 
    namespace _ = ::CoreLib::System::Reflection;
    // Method : System.Reflection.AssemblyName.nInit(out System.Reflection.RuntimeAssembly, bool)
    void AssemblyName::nInit_Out(_::RuntimeAssembly*& assembly, bool raiseResolveEvent)
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.AssemblyName.nGetFileInformation(string)
    _::AssemblyName* AssemblyName::nGetFileInformation(string* s)
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.AssemblyName.nToString()
    string* AssemblyName::nToString()
    {
        throw 3221274624U;
    }
    
    // Method : System.Reflection.AssemblyName.nGetPublicKeyToken()
    __array<uint8_t>* AssemblyName::nGetPublicKeyToken()
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Reflection { 
    namespace _ = ::CoreLib::System::Reflection;
}}}
