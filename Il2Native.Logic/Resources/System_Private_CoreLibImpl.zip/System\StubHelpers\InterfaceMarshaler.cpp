#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace StubHelpers { 
    namespace _ = ::CoreLib::System::StubHelpers;
    // Method : System.StubHelpers.InterfaceMarshaler.ConvertToNative(object, System.IntPtr, System.IntPtr, int)
    ::CoreLib::System::IntPtr InterfaceMarshaler::ConvertToNative(object* objSrc, ::CoreLib::System::IntPtr itfMT, ::CoreLib::System::IntPtr classMT, int32_t flags)
    {
        throw 3221274624U;
    }
    
    // Method : System.StubHelpers.InterfaceMarshaler.ConvertToManaged(System.IntPtr, System.IntPtr, System.IntPtr, int)
    object* InterfaceMarshaler::ConvertToManaged(::CoreLib::System::IntPtr pUnk, ::CoreLib::System::IntPtr itfMT, ::CoreLib::System::IntPtr classMT, int32_t flags)
    {
        throw 3221274624U;
    }
    
    // Method : System.StubHelpers.InterfaceMarshaler.ClearNative(System.IntPtr)
    void InterfaceMarshaler::ClearNative(::CoreLib::System::IntPtr pUnk)
    {
        throw 3221274624U;
    }
    
    // Method : System.StubHelpers.InterfaceMarshaler.ConvertToManagedWithoutUnboxing(System.IntPtr)
    object* InterfaceMarshaler::ConvertToManagedWithoutUnboxing(::CoreLib::System::IntPtr pNative)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace StubHelpers { 
    namespace _ = ::CoreLib::System::StubHelpers;
}}}
