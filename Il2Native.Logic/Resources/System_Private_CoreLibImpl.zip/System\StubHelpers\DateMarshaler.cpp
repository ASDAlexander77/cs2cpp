#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace StubHelpers { 
    namespace _ = ::CoreLib::System::StubHelpers;
    // Method : System.StubHelpers.DateMarshaler.ConvertToNative(System.DateTime)
    double DateMarshaler::ConvertToNative(::CoreLib::System::DateTime managedDate)
    {
        throw 3221274624U;
    }
    
    // Method : System.StubHelpers.DateMarshaler.ConvertToManaged(double)
    int64_t DateMarshaler::ConvertToManaged(double nativeDate)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace StubHelpers { 
    namespace _ = ::CoreLib::System::StubHelpers;
}}}
