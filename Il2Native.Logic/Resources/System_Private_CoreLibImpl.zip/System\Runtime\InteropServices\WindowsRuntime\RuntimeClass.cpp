#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Runtime { namespace InteropServices { namespace WindowsRuntime { 
    namespace _ = ::CoreLib::System::Runtime::InteropServices::WindowsRuntime;
    // Method : System.Runtime.InteropServices.WindowsRuntime.RuntimeClass.GetRedirectedGetHashCodeMD()
    ::CoreLib::System::IntPtr RuntimeClass::GetRedirectedGetHashCodeMD()
    {
        throw 3221274624U;
    }
    
    // Method : System.Runtime.InteropServices.WindowsRuntime.RuntimeClass.RedirectGetHashCode(System.IntPtr)
    int32_t RuntimeClass::RedirectGetHashCode(::CoreLib::System::IntPtr pMD)
    {
        throw 3221274624U;
    }
    
    // Method : System.Runtime.InteropServices.WindowsRuntime.RuntimeClass.GetRedirectedToStringMD()
    ::CoreLib::System::IntPtr RuntimeClass::GetRedirectedToStringMD()
    {
        throw 3221274624U;
    }
    
    // Method : System.Runtime.InteropServices.WindowsRuntime.RuntimeClass.RedirectToString(System.IntPtr)
    string* RuntimeClass::RedirectToString(::CoreLib::System::IntPtr pMD)
    {
        throw 3221274624U;
    }
    
    // Method : System.Runtime.InteropServices.WindowsRuntime.RuntimeClass.GetRedirectedEqualsMD()
    ::CoreLib::System::IntPtr RuntimeClass::GetRedirectedEqualsMD()
    {
        throw 3221274624U;
    }
    
    // Method : System.Runtime.InteropServices.WindowsRuntime.RuntimeClass.RedirectEquals(object, System.IntPtr)
    bool RuntimeClass::RedirectEquals(object* obj, ::CoreLib::System::IntPtr pMD)
    {
        throw 3221274624U;
    }

}}}}}

namespace CoreLib { namespace System { namespace Runtime { namespace InteropServices { namespace WindowsRuntime { 
    namespace _ = ::CoreLib::System::Runtime::InteropServices::WindowsRuntime;
}}}}}
