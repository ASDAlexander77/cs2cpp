#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Threading { 
    namespace _ = ::CoreLib::System::Threading;
    // Method : System.Threading.OverlappedData.AllocateNativeOverlapped()
    _::NativeOverlapped* OverlappedData::AllocateNativeOverlapped()
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.OverlappedData.FreeNativeOverlapped(System.Threading.NativeOverlapped*)
    void OverlappedData::FreeNativeOverlapped(_::NativeOverlapped* nativeOverlappedPtr)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.OverlappedData.GetOverlappedFromNative(System.Threading.NativeOverlapped*)
    _::OverlappedData* OverlappedData::GetOverlappedFromNative(_::NativeOverlapped* nativeOverlappedPtr)
    {
        throw 3221274624U;
    }
    
    // Method : System.Threading.OverlappedData.CheckVMForIOPacket(out System.Threading.NativeOverlapped*, out uint, out uint)
    void OverlappedData::CheckVMForIOPacket_Out_Out_Out(_::NativeOverlapped*& pOVERLAP, uint32_t& errorCode, uint32_t& numBytes)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Threading { 
    namespace _ = ::CoreLib::System::Threading;
}}}
