#include "System.Private.CoreLib.h"

namespace CoreLib { namespace System { namespace Diagnostics { 
    namespace _ = ::CoreLib::System::Diagnostics;
    // Method : System.Diagnostics.Assert.ShowDefaultAssertDialog(string, string, string, string)
    int32_t Assert::ShowDefaultAssertDialog(string* conditionString, string* message, string* stackTrace, string* windowTitle)
    {
        throw 3221274624U;
    }

}}}

namespace CoreLib { namespace System { namespace Diagnostics { 
    namespace _ = ::CoreLib::System::Diagnostics;
}}}
