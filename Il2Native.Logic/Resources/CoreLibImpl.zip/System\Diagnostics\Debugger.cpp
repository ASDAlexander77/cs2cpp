#include "CoreLib.h"

namespace CoreLib {
	namespace System {
		namespace Diagnostics {

			// Method : System.Diagnostics.Debugger.IsAttached.get
			bool Diagnostics::Debugger::get_IsAttached()
			{
				throw 0xC000C000;
			}

			// Method : System.Diagnostics.Debugger.Break()
			void Diagnostics::Debugger::Break()
			{
				throw 0xC000C000;
			}
		}
	}
}